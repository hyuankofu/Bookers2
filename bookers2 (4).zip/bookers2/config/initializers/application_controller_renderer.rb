# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'd7e0915158c2bdeab91631d59e47664158bf1891b7d876894659f7fa8e87d1af77800b5dfacc9f9a0c1dc41092d3f4e450d4290e5597be7bc1bb35509d288407'